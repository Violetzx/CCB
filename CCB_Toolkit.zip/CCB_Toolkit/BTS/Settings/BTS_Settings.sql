INSERT OR REPLACE INTO BTS_Settings VALUES
    ("BTS_ApproximateTraderPath", 0),
    ("BTS_ShowSortPriorities", 0),
    ("BTS_ShowAllRoutePaths", 1),
    ("BTS_ShowTraderPathOnSelection", 1);
