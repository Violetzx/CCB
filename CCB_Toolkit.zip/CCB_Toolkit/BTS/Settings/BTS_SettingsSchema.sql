CREATE TABLE 'BTS_Settings' (
  'Setting' TEXT NOT NULL,
  'Value' INTEGER NOT NULL,
  PRIMARY KEY('Setting')
);
