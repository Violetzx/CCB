UPDATE Parameters SET DefaultValue = "0" WHERE ParameterId = "GameMode_Monopolies";
UPDATE Parameters SET DefaultValue = "0" WHERE ParameterId = "GameMode_SecretSocieties";